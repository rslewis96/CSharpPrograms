﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WMPLib;

namespace KaijuGuessingGame
{
    public partial class FrmKaijuGame : Form
    {
        //Initialize variables
        int rounds = 3;
        string guess;


        //var path = System.IO.Path.Combine(System.AppDomain.CurrentDomain.BaseDirectory, "_Roar\\KaijuList.txt");
        //string[] kaujiName = File.ReadAllLines(@"C:\Users\rslew\Desktop\C# Programs\KaijuGuessingGame\KaijuList.txt");
        string[] kaujiName = File.ReadAllLines(@".\KaijuList.txt");


        public FrmKaijuGame()
        {
            InitializeComponent();
        }

        public int RandomGenerateKaiju()
        {
            //Pull in number of Kaiju
            var kaijuCount = File.ReadAllLines(@".\KaijuList.txt").Length;
            //Randomly generate number that correlates to a kaiju on list
            Random rnd = new Random();
            int numKaiju = rnd.Next(1, kaijuCount + 1);

            return numKaiju;
        }

        public void PlayRoar (int numKaiju)
        {
            //Play audio of Kaiju roar
            WindowsMediaPlayer myplayer = new WindowsMediaPlayer();
            myplayer.URL = @".\_Roar\" + numKaiju.ToString() + ".mp3";
            myplayer.controls.play();
        }

        private void BtnRoar_Click(object sender, EventArgs e)
        {
            
            int kaijuNumber = RandomGenerateKaiju(); //Calls the RandomGenerateKaiju function
            string GuessResult = "";
            string hearAgain = "";
            string guess = "";
            int guessCount = 3;

            PlayRoar(kaijuNumber);

            while (guessCount != 0)
            {
                guess = Microsoft.VisualBasic.Interaction.InputBox("Which Kaiju is this?", "Your guess...", "");

                if (guess == kaujiName[kaijuNumber - 1])
                {
                    //MessageBox.Show("CORRECT! The kaiju roar was " + kaujiName[kaijuNumber - 1]);

                    GuessResult = "Correct!";
                    break;
                }
                else
                {
                    guessCount--;
                    if (guessCount > 0)
                    {
                        hearAgain = Microsoft.VisualBasic.Interaction.InputBox("Incorrect! " + guessCount + " guesses left.Hear roar again ? y/n", "Incorrect!", "");
                        if (hearAgain == "y")
                        {
                            PlayRoar(kaijuNumber);
                        }
                    }
                    else
                    { 
                        GuessResult = "Incorrect!";
                    }

                }

            }

            FrmRoarGuess f = new FrmRoarGuess(kaijuNumber, kaujiName, GuessResult);
            f.ShowDialog();

        }

        private void BtnPicture_Click(object sender, EventArgs e)
        {
            int kaijuNumber = RandomGenerateKaiju(); //Calls the RandomGenerateKaiju function
            FrmPictureGuess g = new FrmPictureGuess(kaijuNumber, kaujiName);
            g.ShowDialog();
        }
    }
}
