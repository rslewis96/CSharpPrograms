﻿//Used to pull mp3 files - https://stackoverflow.com/questions/32588277/c-sharp-play-embedded-mp3-file
//Used to get number of Kaiju in file -  https://stackoverflow.com/questions/119559/determine-the-number-of-lines-within-a-text-file



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace KaijuGuessingGame
{
    public partial class FrmRoarGuess : Form
    {
        public FrmRoarGuess(int kaijuNumber,string [] kaujiName, string GuessResult)
        {

            InitializeComponent();
            lblGuessResult.Text = GuessResult;
            lblKaijuName.Text =  kaujiName[kaijuNumber - 1];
            PicBoxKaiju.Image = Image.FromFile(@".\_Picture\" + kaijuNumber.ToString() + ".jpg");
        
        }

        private void FrmRoarGuess_Load(object sender, EventArgs e)
        {
            
        }

        private void btnExitGame_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void btnPlayAgain_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
