﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KaijuGuessingGame
{
    public partial class FrmPictureGuess : Form
    {
        string name;

        public FrmPictureGuess(int kaijuNumber, string[] kaujiName)
        {
            InitializeComponent();
            //lblKaijuName.Text = kaujiName[kaijuNumber - 1];
            picBoxRndKaiju.Image = Image.FromFile(@".\_Picture\" + kaijuNumber.ToString() + ".jpg");

            this.name = kaujiName[kaijuNumber - 1];
        }

        private void picBoxRndKaiju_Click(object sender, EventArgs e)
        {

        }

        private void FrmPictureGuess_Load(object sender, EventArgs e)
        {

        }

        private void btnCheckAnswer_Click(object sender, EventArgs e)
        {
            if(name == txtBoxAnswer.Text)
            {
                MessageBox.Show("Correct!");
                //PlayRoar(kaijuNumber);
            }
            else
            {
                MessageBox.Show("Incorrect! The Kaiju shown is " + name + ".");
            }

        }

        private void btnPlayAgain_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }
    }
}
