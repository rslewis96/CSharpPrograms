﻿
namespace KaijuGuessingGame
{
    partial class FrmKaijuGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnRoar = new System.Windows.Forms.Button();
            this.BtnPicture = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnRoar
            // 
            this.BtnRoar.Location = new System.Drawing.Point(73, 72);
            this.BtnRoar.Name = "BtnRoar";
            this.BtnRoar.Size = new System.Drawing.Size(165, 52);
            this.BtnRoar.TabIndex = 0;
            this.BtnRoar.Text = "Guess Kaiju by Roar";
            this.BtnRoar.UseVisualStyleBackColor = true;
            this.BtnRoar.Click += new System.EventHandler(this.BtnRoar_Click);
            // 
            // BtnPicture
            // 
            this.BtnPicture.Location = new System.Drawing.Point(73, 151);
            this.BtnPicture.Name = "BtnPicture";
            this.BtnPicture.Size = new System.Drawing.Size(165, 52);
            this.BtnPicture.TabIndex = 1;
            this.BtnPicture.Text = "Guess Kaiju by Picture";
            this.BtnPicture.UseVisualStyleBackColor = true;
            // 
            // FrmKaijuGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(311, 280);
            this.Controls.Add(this.BtnPicture);
            this.Controls.Add(this.BtnRoar);
            this.Name = "FrmKaijuGame";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Kaiju Guessing Game";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnRoar;
        private System.Windows.Forms.Button BtnPicture;
    }
}

