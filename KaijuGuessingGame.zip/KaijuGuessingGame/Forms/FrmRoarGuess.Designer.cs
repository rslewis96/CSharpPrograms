﻿
namespace KaijuGuessingGame
{
    partial class FrmRoarGuess
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PicBoxKaiju = new System.Windows.Forms.PictureBox();
            this.lblKaijuName = new System.Windows.Forms.Label();
            this.lblGuessResult = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.PicBoxKaiju)).BeginInit();
            this.SuspendLayout();
            // 
            // PicBoxKaiju
            // 
            this.PicBoxKaiju.Location = new System.Drawing.Point(116, 97);
            this.PicBoxKaiju.Name = "PicBoxKaiju";
            this.PicBoxKaiju.Size = new System.Drawing.Size(254, 248);
            this.PicBoxKaiju.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PicBoxKaiju.TabIndex = 1;
            this.PicBoxKaiju.TabStop = false;
            // 
            // lblKaijuName
            // 
            this.lblKaijuName.AutoSize = true;
            this.lblKaijuName.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKaijuName.Location = new System.Drawing.Point(172, 63);
            this.lblKaijuName.Name = "lblKaijuName";
            this.lblKaijuName.Size = new System.Drawing.Size(146, 31);
            this.lblKaijuName.TabIndex = 2;
            this.lblKaijuName.Text = "KaijuName";
            this.lblKaijuName.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblGuessResult
            // 
            this.lblGuessResult.AutoSize = true;
            this.lblGuessResult.Location = new System.Drawing.Point(223, 30);
            this.lblGuessResult.Name = "lblGuessResult";
            this.lblGuessResult.Size = new System.Drawing.Size(35, 13);
            this.lblGuessResult.TabIndex = 3;
            this.lblGuessResult.Text = "label1";
            this.lblGuessResult.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(146, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(194, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "The name of the Kaiju is... ";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // FrmRoarGuess
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(489, 383);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblGuessResult);
            this.Controls.Add(this.lblKaijuName);
            this.Controls.Add(this.PicBoxKaiju);
            this.Name = "FrmRoarGuess";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Kaiju Reveal";
            this.Load += new System.EventHandler(this.FrmRoarGuess_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PicBoxKaiju)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox PicBoxKaiju;
        private System.Windows.Forms.Label lblKaijuName;
        private System.Windows.Forms.Label lblGuessResult;
        private System.Windows.Forms.Label label2;
    }
}