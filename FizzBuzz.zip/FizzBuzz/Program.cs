﻿//Write a program that prints the numbers from 1 to 100.
//For multiples of three print "Fizz" instead of the number, for multiples of five print "Buzz" instead of the number,
//and for numbers that are mulitple of both three and fifteen print "Buzz" instead of the number.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FizzBuzz
{
    class Program
    {
        static void Main(string[] args)
        {

            for(int i = 1 ;i <= 100 ;i++)
            {

                if (i % 15 == 0)
                {
                    Console.Write("FizzBuzz\n");
                }
                else if(i % 3 == 0)
                {
                    Console.Write("Fizz\n");
                }
                else if (i % 5 == 0)
                {
                    Console.Write("Buzz\n");
                }
                else
                {
                    Console.Write(i);
                    Console.Write("\n");
                }
            }




        }
    }
}
